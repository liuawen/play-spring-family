package com.example.ribbon.config;

import org.springframework.cloud.netflix.ribbon.RibbonClient;

//@RibbonClient(name="user-service", configuration=BeanConfiguration.class)
public class RibbonClientConfig {
	
}
