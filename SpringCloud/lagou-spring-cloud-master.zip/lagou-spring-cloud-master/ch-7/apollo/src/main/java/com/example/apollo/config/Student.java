package com.example.apollo.config;

import lombok.Data;

@Data
public class Student {

	private int id;
	
	private String name;
	
}
