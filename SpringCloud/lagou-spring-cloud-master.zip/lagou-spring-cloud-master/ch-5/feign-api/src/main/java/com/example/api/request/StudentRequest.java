package com.example.api.request;

import lombok.Data;

@Data
public class StudentRequest {

	private String name;
	
	private int age;
	
}
